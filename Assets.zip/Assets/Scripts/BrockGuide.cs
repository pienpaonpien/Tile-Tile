using UnityEngine;

public class BrockGuide : MonoBehaviour
{
    [Header("--- �󂯕t����u���b�N�ԍ� ---")]
    public int targetBrockNum;

    [Header("--- �z������̋��e���� ---")]
    public float snapDistance = 0.3f;

    [Header("--- ��Ԋm�F�p ---")]
    public bool isFilled;

    [Header("--- ������ɒʉߕs�ɂ���Collider ---")]
    [SerializeField] private Collider2D guideCollider;

    private Brock currentBrock;
    private Hand playerHand;

    private void Start()
    {
        playerHand = FindFirstObjectByType<Hand>();

        if (guideCollider == null)
        {
            guideCollider = GetComponent<Collider2D>();
        }

        SetGuideBlocking(false);
    }

    private void OnTriggerStay2D(Collider2D other)
    {
        if (isFilled)
        {
            return;
        }

        Brock brock = other.GetComponentInParent<Brock>();

        if (brock == null)
        {
            return;
        }

        if (brock.brockNum != targetBrockNum)
        {
            return;
        }

        if (brock.IsPlaced)
        {
            return;
        }

        float distance = Vector2.Distance(
            brock.transform.position,
            transform.position
        );

        if (distance > snapDistance)
        {
            return;
        }

        if (brock.IsHeld && playerHand != null)
        {
            playerHand.ForceReleaseForPlacement();
        }

        SnapBrock(brock);
    }

    private void SnapBrock(Brock brock)
    {
        if (brock == null || isFilled)
        {
            return;
        }

        currentBrock = brock;
        currentBrock.SetPlaced(transform.position);

        isFilled = true;

        SetGuideBlocking(true);

        Debug.Log(
            $"�u���b�N({brock.brockNum})��"
            + $"�K�C�h({targetBrockNum})�ɔz�u����܂���"
        );

        if (GameManager.Instance != null)
        {
            GameManager.Instance.CheckClearConditionNow();
        }
    }

    private void SetGuideBlocking(bool blocking)
    {
        if (guideCollider == null)
        {
            return;
        }

        /*
         * �󂢂Ă����:
         * Trigger�Ƃ��ċz������Ɏg�p
         *
         * ������:
         * �ʏ�Collider�ɂ��Ēʉߕs�ɂ���
         */
        guideCollider.isTrigger = !blocking;
    }

    public void ResetGuide()
    {
        isFilled = false;
        currentBrock = null;

        SetGuideBlocking(false);
    }
}